const fs = require('fs-extra');
const path = require('path');
const concat = require('concat');
const crypto = require('crypto');

const outputFolder = 'widget';
const outputFileName = 'dinosaurs-widget';
const distFolder = './dist/angular-web-component/';
const sortFiles = [
    'runtime',
    'polyfills',
    'main'
];

get16DigitsCode = (sortedFiles) => {
    let fileBuffer = null;
    sortedFiles.forEach(sfile => {
        fileBuffer += fs.readFileSync(sfile);
    });

    const hashSum = crypto.createHash('sha256');
    hashSum.update(fileBuffer);
    const hash = hashSum.digest('hex');

    const first16HexCharacters = hash.slice(0, 16);
    return first16HexCharacters;
};
fillCopyTemplate = (widgetFile) => {
    const finalFile = `./${outputFolder}/index.html`;
    fs.copySync(path.resolve(__dirname, './index.template.html'), finalFile, { overwrite: true });
    let content = fs.readFileSync(finalFile, "utf8");
    content = content.replace('{placeholder}', widgetFile);
    fs.outputFileSync(finalFile, content, { overwrite: true });
};
build = async() => {
    const sortedFiles = [];
    const files = [];

    fs.readdirSync(distFolder).forEach(filename => {
        const name = path.parse(filename).name;
        const ext = path.parse(filename).ext;
        const filepath = path.resolve(distFolder, filename);
        const stat = fs.statSync(filepath);
        const isFile = stat.isFile();

        if (isFile) files.push(`${distFolder}${name}${ext}`);
    });

    sortFiles.forEach(sfile => {
        sortedFiles.push(files.find(x => x.includes(sfile)));
    });

    const widgetFile = `${outputFileName}.${get16DigitsCode(sortedFiles)}.js`;

    await fs.ensureDir(outputFolder);
    await concat(sortedFiles, `${outputFolder}/${widgetFile}`);
    fillCopyTemplate(widgetFile);
}
build();