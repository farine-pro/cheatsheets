import { DoBootstrap, Injector, NgModule } from "@angular/core";
import { createCustomElement } from '@angular/elements';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { DinosaursComponent } from './dinosaurs/dinosaurs.component';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from "./shared.module";

@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        BrowserModule,
        HttpClientModule,
        SharedModule
    ],
    providers: [],
    bootstrap: []
})
export class AppModule implements DoBootstrap {
  constructor(private injector: Injector) {
  }
  public ngDoBootstrap(): void {
    const el = createCustomElement(DinosaursComponent, { injector:this.injector });
    customElements.define('dinosaurs-widget', el);
  }
}
