import { Component, Input, OnInit } from '@angular/core';
import { DataService } from '../data.service';
@Component({
  selector: 'app-dinosaurs',
  templateUrl: './dinosaurs.component.html',
  styleUrls: ['./dinosaurs.component.css']
})
export class DinosaursComponent implements OnInit {
  articles: any;

  @Input()
  dinosaur: String | undefined;

  constructor(private dataService: DataService) { }
  ngOnInit() {
    this.dataService.get().subscribe((data) => {
      // console.log(data);
      this.articles = data;
      if (this.dinosaur) {
        this.articles = [this.articles.find((x: { name: String | undefined; }) => x.name == this.dinosaur)];
      }
    });
  }
}