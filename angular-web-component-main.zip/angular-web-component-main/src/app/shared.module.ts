import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DinosaursComponent } from './dinosaurs/dinosaurs.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    DinosaursComponent
  ],
  exports: [
    DinosaursComponent
  ],
})
export class SharedModule { }