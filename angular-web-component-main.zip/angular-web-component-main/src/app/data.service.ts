import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class DataService {
  

  constructor(private httpClient: HttpClient) { }  

  get(){
    return this.httpClient.get(`https://raw.githubusercontent.com/auth0-blog/sample-nodeserver-dinos/master/dinosaurs.json`);
  }
}